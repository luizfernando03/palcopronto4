package br.com.javeirosavante.palcopronto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PalcoprontoApplicationTests {

	@Test
	void contextLoads() {
	}

}
